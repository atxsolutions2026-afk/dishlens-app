import { redirect } from "next/navigation";

export default function LegacyQrRedirect() {
  redirect("/r/qr");
}
